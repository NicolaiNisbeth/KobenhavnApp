package com.example.kobenhavn.ui.legepladser;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.kobenhavn.R;

public class LegepladserFragment extends Fragment {

    private LegepladserViewModel legepladserViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        legepladserViewModel =
                ViewModelProviders.of(this).get(LegepladserViewModel.class);
        View root = inflater.inflate(R.layout.fragment_legepladser, container, false);
        final TextView textView = root.findViewById(R.id.text_legepladser);
        legepladserViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }
}
