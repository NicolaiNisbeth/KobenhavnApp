package com.example.kobenhavn.ui.aktiviteter;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AktiviteterViewModel extends ViewModel {

    private MutableLiveData<String> text;

    public AktiviteterViewModel() {
        text = new MutableLiveData<>();
        text.setValue("This is aktiviteter fragment");
    }

    public LiveData<String> getText() {
        return text;
    }
}